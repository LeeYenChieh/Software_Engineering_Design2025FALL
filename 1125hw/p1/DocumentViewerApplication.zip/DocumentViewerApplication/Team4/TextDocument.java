public class TextDocument extends Document{
    public TextDocument(String path){
        super(path);
    }
}
