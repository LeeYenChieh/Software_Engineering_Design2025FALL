public abstract class Document {
    public String path;

    public Document(String path){
        this.path = path;
    }
}
