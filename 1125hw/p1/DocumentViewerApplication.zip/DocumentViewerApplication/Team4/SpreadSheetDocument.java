public class SpreadSheetDocument extends Document{
    public SpreadSheetDocument(String path){
        super(path);
    }
}
