public class Staff extends User {
    public Staff(String name){
        super(name);
    }
}
